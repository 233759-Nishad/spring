package com.Jpa.M2M;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M2MApplication {

	public static void main(String[] args) {
		SpringApplication.run(M2MApplication.class, args);
	}

}
